<a href="index.php">
            <img src="img/Banner.gif" alt="image not found" class="logo">
</a>
<div class="header">
    <table bgcolor="whitesmoke" height="100" width="990" border="0" >
        <tr bgcolor="whitesmoke">
            <td width="50"></td>
            <td width="790" bgcolor="whitesmoke" colspan="3" align="center">
                <a href="index.php"><b>Trang chủ</b></a> |
                <a href="location.php"><b>Thông tin liên hệ</b></a> |
                <a href=""><b>Góp ý</b></a> 
            </td>
            <td width="100"></td>   
        </tr>
        <tr bgcolor="whitesmoke">
            <td width="50"></td>
            <td width="400"></td>
            <td width="540" bgcolor="whitesmoke" colspan="3">
                <?php
                        include ("modules/mDangNhapTaiKhoan.php");
                ?>
            </td>
            
        </tr>  
    </table>
</div>

<div class="sliderboxHead">
    <div id="sliderbox" >
        <img src="img/EmptyRoom.png" alt="image not found">
        <img src="img/PrisonBreak.jpg" alt="image not found">
        <img src="img/Grid.jpg" alt="image not found">
        <img src="img/PrisonRoom.jpg" alt="image not found">
        <img src="img/Prison.jpg" alt="image not found">
    </div>
</div>