<?php
    $db_host="localhost";
    $db_username="root";
    $db_password="";
    $db_name="ql_nhatu";
?>