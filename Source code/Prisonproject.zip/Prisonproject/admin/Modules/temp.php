<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="./CSS/style.css">
</head>
<body>
            <table class="tHeader"  border="6" >
                <td bgcolor="#e1d9f9">
                    <font size="6">
                        <a href=".././index.php" class='push_button blue'><b>Trang chủ</b></a>|
                        <a href="location.php" class='push_button red'><b>Thông tin liên hệ</b></a>|
                        <a href=".././index.php" class='push_button blue'><b>Đăng Xuất</b></a>                
                    </font>
                </td> 
        </table>

</body>
</html>
