<table >
        <tr>
            <td width='35%' bgcolor='#e3e9f2'  valign='top'>
                <table border='1'>
                    <tr>
                        <td width="252" bgcolor="#e8dede">
                            <h4> Quản trị viên  : </h4>
                            <ul>
                                <li><a href='viewofficer.php' ><b><button>Danh sách thân nhân</button></b></a></li>
                                <br>
                                <li><a href='viewprisoners.php'><b><button>Danh sách tù nhân</button></b></a></li>
                                <br>
                                <li><a href='viewcase.php'><b><button>Danh sách các cán bộ </button></b></a></li>
                                <br>
                                <li><a href='viewtransfer.php'><b><button>Bộ quản giáo </button></b></a></li>
                                <br>
                                <li><a href='viewvis.php'><b><button>Bộ phận y tế</button></b></a></li>
                                <br>
                                <li><a href='viewoff.php'><b><button>Bộ phận tiếp nhận & phóng thích</button></b></a></li>
                                <br>
                                <li><a href='viewnewprison.php'><b><button>Bộ phận quản lý</button></b></a></li>
                                <br>
                                <li><a href='viewcourt.php'><b><button>Bộ phận cải tạo</button></b></a></li>
                                <br>
                                <li><a href='viewAnnounce.php'><b><button>Thêm & Xóa thông tin tù nhân</button></b></a></li>
                                <br>
                                <li><a href='report.php'><b><button>Xem báo cáo theo đợt</button></b></a></li>
                            </ul>
                        </td>
                    </tr>
                </table>
            </td>
            
        </tr>
            
</table>