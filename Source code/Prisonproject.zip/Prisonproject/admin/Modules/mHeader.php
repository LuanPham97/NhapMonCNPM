        <table class="tHeader"  border="6" >
                <td bgcolor="#e1d9f9">
                    <font size="6">
                        <a href=".././index.php" class='push_button blue'><b>Trang chủ</b></a>&nbsp;&nbsp;|
                        <a href="location.php" class='push_button blue'><b>Thông tin liên hệ</b></a>&nbsp;&nbsp;|
                        <a href=".././index.php" class='push_button red'><b>Đăng Xuất</b></a>                
                    </font>
                </td> 
        </table>
<?php
    if(!isset($_SESSION["maLoaiTaiKhoan"]))
    {
        DataProvider::ChangeURL('.././index.php');
    }

?>