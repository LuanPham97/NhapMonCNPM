
        <td width='65%' valign='top' bgcolor="#FFFFFF">
    <p align='center'>
        <h3 align='center'>&nbsp;</h3>
        <br>
        <h2 align='center'>Dành cho quản trị viên</h2>
        <P align='justify'>
        <font size="4">
        <p>
            Hệ thống cho phép quản trị viên cung cấp dịch vụ cho người dùng ở đây, quản trị viên có thể thêm và tải lên thông tin, cập nhật, xóa, xem thông tin tù nhân và người dùng được thêm vào.
            Quản trị viên cũng có thể thay đổi tài khoản của mình để bảo mật hơn.
        </p>
        </font>
        </p>
    </p>
    <br>
</td>