<div id="Thongtintaikhoan">
    <?php
        echo"<font size='5'> Hello, ".$_SESSION['tenHienThi']." | </font>";
    ?>
    <a href=".././index.php?a=4"><b>Đăng Xuất</b></a>
</div>          