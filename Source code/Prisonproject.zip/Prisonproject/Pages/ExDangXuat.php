<?php
    session_destroy();
    DataProvider::ChangeURL("index.php");
?>