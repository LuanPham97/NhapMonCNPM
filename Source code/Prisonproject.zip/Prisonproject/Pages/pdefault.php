<table align ="center" border="0" bgcolor="#000000" width="950" cellpadding="0" cellspacing ="0" height=300">
        <tr>
            <td width="50%" align="center" bgcolor="#e8ebef">     
                <div class="ex">
                    <!-- <h2 class="bg-primary">Prison Management System Online </h2> -->
                    <h2 class="bg-primary">Hệ Thống Quản Lý Nhà Tù Trực Tuyến </h2>
                       
                </div>
            </td>
        </tr>
</table>