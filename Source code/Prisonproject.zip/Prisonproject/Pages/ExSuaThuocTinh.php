<?php

if(isset($_GET["b"]) && $_GET["b"] == 1)
{
    if(isset($_POST["nbMaPhamNhan"]) && isset($_POST["nbMaPhamNhan"])!="" )
    {
        $maPhamNhan = $_POST["nbMaPhamNhan"];
        if(isset($_POST["nbMaTinhTrang"]) && $_POST["nbMaTinhTrang"] != "")
        {
            $maTinhTrang = $_POST["nbMaTinhTrang"];

                $sql = "UPDATE PhamNhan
                        SET TinhTrangSucKhoe = '$maTinhTrang'
                        WHERE MaPhamNhan = '$maPhamNhan' ";
                DataProvider::ExecuteQuery($sql);
        }

        
        if(isset($_POST["txtNgayKTDK"]) && $_POST["txtNgayKTDK"] != "")
        {
            $NgayKTDinhKy = $_POST["txtNgayKTDK"];
            $sql = "UPDATE PhamNhan 
            SET NgayKTDinhKy = '$NgayKTDinhKy'
            WHERE MaPhamNhan = '$maPhamNhan' ";
            DataProvider::ExecuteQuery($sql);
        }   
    }
    DataProvider::ChangeURL(".././User/Yte.php?a=2");
}

if(isset($_GET["b"]) && $_GET["b"] == 2 && isset($_POST["nbMaPhamNhan"]) 
        && isset($_POST["txtCheDoTheoDoi"]))
{
    $maPhamNhan = $_POST["nbMaPhamNhan"];
    $CheDoTheoDoi= $_POST["txtCheDoTheoDoi"];
   
    $sql = "UPDATE PhamNhan
            SET CheDoTheoDoi = '$CheDoTheoDoi'
            WHERE MaPhamNhan = '$maPhamNhan'";
    DataProvider::ExecuteQuery($sql);
    DataProvider::ChangeURL(".././User/CanBo.php?a=7");
}


?>