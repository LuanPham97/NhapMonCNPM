<h1 align="Center">Quản Lý Cán Bộ</h1>
<h4>Thêm Thông Tin Cán Bộ: <a href="index.php?a=13"><button>Thêm</button></a></h4>
<h4>Xóa Thông Tin Cán Bộ: <a href="index.php?a=15"><button>Xóa</button></a></h4>
<h4>Sửa Thông Tin Cán Bộ: <a href="index.php?a=14"><button>Sửa</button></a></h4>
<h4>Liệt Kê Thông Tin Cán Bộ: <a href="index.php?a=16"><button>Liệt Kê</button></a></h4>
