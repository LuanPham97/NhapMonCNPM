<h1 align="Center">Quản Lý Tài Khoản</h1>
<h4>Thêm Thông Tin Tài Khoản: <a href="index.php?a=18"><button>Thêm</button></a></h4>
<h4>Xóa Thông Tin Tài Khoản: <a href="index.php?a=19"><button>Xóa</button></a></h4>
<h4>Cập Nhật Thông Tin Tài Khoản: <a href="index.php?a=20"><button>Cập Nhật</button></a></h4>
<h4>Liệt Kê Thông Tin Tài Khoản: <a href="index.php?a=21"><button>Liệt Kê</button></a></h4>