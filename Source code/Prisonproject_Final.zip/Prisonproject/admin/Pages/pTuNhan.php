<h1 align="Center">Quản Lý Tù Nhân</h1>
<h4>Thêm Thông Tin Tù Nhân: <a href="index.php?a=8"><button>Thêm</button></a></h4>
<h4>Xóa Thông Tin Tù Nhân: <a href="index.php?a=9"><button>Xóa</button></a></h4>
<h4>Sửa Thông Tin Tù Nhân: <a href="index.php?a=10"><button>Sửa</button></a></h4>
<h4>Liệt Kê Tù Nhân: <a href="index.php?a=11"><button>Liệt Kê</button></a></h4>
