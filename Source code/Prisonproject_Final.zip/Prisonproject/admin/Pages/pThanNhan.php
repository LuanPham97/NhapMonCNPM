<h1 align="Center">Quản Lý Thân Nhân</h1>
<h4>Thêm Thông Tin Thân Nhân: <a href="index.php?a=3"><button>Thêm</button></a></h4>
<h4>Xóa Thông Tin Thân Nhân: <a href="index.php?a=5"><button>Xóa</button></a></h4>
<h4>Sửa Thông Tin Thân Nhân: <a href="index.php?a=6"><button>Sửa</button></a></h4>
<h4>Liệt Kê Thân Nhân: <a href="index.php?a=4"><button>Liệt Kê</button></a></h4>
