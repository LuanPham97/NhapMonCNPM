<table >
            <tr>
                <td width='35%' bgcolor='#e3e9f2'  valign='top'>
                    <table border='1'>
                        <tr>
                            <td width="252" bgcolor="#e8dede">
                                <h4> Quản trị viên  : </h4>
                                <ul class='nav'>
                                    <li><a href='index.php?a=2' ><b><button>THÂN NHÂN</button></b></a>
                                    </li>
                                    <br>
                                    <li><a href='index.php?a=7'><b><button>TÙ NHÂN</button></b></a></li>
                                    <br>
                                    <li><a href='index.php?a=12'><b><button>CÁN BỘ </button></b></a></li>
                                    <br>
                                    <li><a href='index.php?a=17'><b><button>TÀI KHOẢN</button></b></a></li>
                                </ul>
                            </td>
                        </tr>
                    </table>
                </td>
                
            </tr>
            
        </table>