<tr>
    <td bgcolor="#4286f4" colspan="3" align="center">
        &copy; Design by student of FIT - HCMUS
    </td>
</tr>