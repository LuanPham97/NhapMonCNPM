<tr>
	<td><?php echo "$tenDangNhap"; ?></td>
	<td><?php echo "$matKhau"; ?></td>
	<td><?php echo "$tenHienThi"; ?></td>
	<td><?php echo "$tenLoaiTaiKhoan"; ?></td>
</tr>