<tr>
	<td><?php echo "$maPhamNhan"; ?></td>
	<td><?php echo "$tenPhamNhan"; ?></td>
	<td><?php echo "$diaChi"; ?></td>
	<td><?php echo "$tinhTrangSucKhoe"; ?></td>
	<td><?php echo "$mucDo"; ?></td>
	<td><?php echo "$kiemTra" ?></td>
	<td><?php echo "$gapNguoiThan" ?></td> 
	<td><?php echo "$mucDoCaiTao" ?></td> 
</tr>
