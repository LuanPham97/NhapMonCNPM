<tr>
	<td><?php echo "$maCanBo"; ?></td>
	<td><?php echo "$ten"; ?></td>
	<td><?php echo "$sdt"; ?></td>
	<td><?php echo "$boPhan"; ?></td>
	<td><?php echo "$tenDangNhap"; ?></td>
</tr>