<tr>
	<td><?php echo "$maThanNhan"; ?></td>
	<td><?php echo "$tenThanNhan"; ?></td>
	<td><?php echo "$soDienThoai"; ?></td>
	<td><?php echo "$tenDangNhap"; ?></td>
</tr>
